// Generated from MCP schema. Routes calls via bindings.runtime.ts
import { callTool } from "./bindings.runtime";
export const bindings = {
  async search_docs(query) {
    return callTool("search_docs", { query: query });
  },
  async summarize(text, sentences) {
    return callTool("summarize", { text: text, sentences: sentences });
  },
} as const;